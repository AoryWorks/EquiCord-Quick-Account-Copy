/*
 * Equicord, a Discord client mod
 * SPDX-License-Identifier: GPL-3.0-or-later
 */

import { UserAreaButton, UserAreaButtonFactory, UserAreaRenderProps } from "@api/UserArea";
import { copyWithToast } from "@utils/discord";
import definePlugin from "@utils/types";
import { findByPropsLazy } from "@webpack";
import { React } from "@webpack/common";

const AuthenticationStore = findByPropsLazy("getToken", "getId");

function WarningIcon(props: React.SVGProps<SVGSVGElement>) {
    return (
        <svg
            {...props}
            width="20"
            height="20"
            viewBox="0 0 24 24"
            fill="currentColor"
        >
            <path d="M12 2L1 21h22L12 2zm1 16h-2v-2h2v2zm0-4h-2V9h2v5z" />
        </svg>
    );
}

function TokenButton({ iconForeground, hideTooltips, nameplate }: UserAreaRenderProps) {
    const handleClick = React.useCallback(() => {
        try {
            const token = AuthenticationStore.getToken();
            if (!token) {
                copyWithToast("Impossible de récupérer le token", "error");
                return;
            }
            copyWithToast(token, "Token copié !");
        } catch (e) {
            console.error("[QuickToken]", e);
            copyWithToast("Erreur lors de la récupération du token", "error");
        }
    }, []);

    return (
        <UserAreaButton
            tooltipText={hideTooltips ? void 0 : "Copier mon token"}
            icon={<WarningIcon className={iconForeground} />}
            plated={nameplate != null}
            onClick={handleClick}
        />
    );
}

const TokenUserAreaButton: UserAreaButtonFactory = props => <TokenButton {...props} />;

export default definePlugin({
    name: "CopierToken",
    description: "Ajoute un bouton dans la zone utilisateur en bas pour copier rapidement le token du compte.",
    authors: [{ name: "Aory", id: 0n }],
    dependencies: ["UserAreaAPI"],

    userAreaButton: {
        icon: WarningIcon,
        render: TokenUserAreaButton,
    },
});